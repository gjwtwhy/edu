<?php
namespace app\month\controller;

use think\Controller;

class Index extends Controller
{
    public function index()
    {
       return view();
    }
}

<?php
namespace app\month\model;

use think\Model;

class ALogistics extends Model
{

}
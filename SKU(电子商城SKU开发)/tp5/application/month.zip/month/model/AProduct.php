<?php
namespace app\month\model;

use think\Model;

class AProduct extends Model
{

}
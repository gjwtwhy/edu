<?php
namespace app\month\model;

use think\Model;

class ASaler extends Model
{

}
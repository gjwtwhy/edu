<?php

namespace app\month\model;

use think\Model;

class BAttr extends Model
{
    //
}

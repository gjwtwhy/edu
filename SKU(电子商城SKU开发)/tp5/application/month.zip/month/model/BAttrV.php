<?php

namespace app\month\model;

use think\Model;

class BAttrV extends Model
{
    //
}

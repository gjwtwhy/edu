<?php

namespace app\month\model;

use think\Model;

class BGoodsSku extends Model
{
    //
}
